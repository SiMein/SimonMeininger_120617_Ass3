package de.assignment3_delivery;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeSet;

//------------------------------GRAPH_CLASS---------------------------------------------
class GraphTemplate {
	ArrayList<Node> nodes;
	ArrayList<Node> minPriorityQueue;
    HashMap<String, Node> graph; 

    public static class Edge { // -------inner class Edge -------------------------------
    	String from, to;		// for connections between two nodes and the weight of edge
    	int distance;
    	public Edge(String from, String to, int distance) {
    		this.from = from;
    		this.to = to;
    		this.distance = distance;
    	}
    } 
							//---------------inner Class Node---------------------  
    public static class Node implements Comparable<Node>{
    	String label;
    	HashMap<Node, Integer> adjacentNodes = new HashMap<>(); //Neighbour-Nodes of this node
    	Node parent = null;
    	int distance = Integer.MAX_VALUE; 
    	public Node(String name){
    		this.label = name;
    	} 
    	private void shortestWay(){		// possible printoutstreams
    		if (this == this.parent){
    			System.out.printf("%s", this.label);
    		}
    		else if (this.parent == null)		{
    			System.out.printf("%s(unreached)", this.label);
    		}
    		else{
    			this.parent.shortestWay();
    			System.out.printf(" -> %s(%d)", this.label, this.distance);
    		}
    	}

    	public int compareTo(Node other)	{	//use java standard-method to check if its the same distance
    		if (distance == other.distance)
    			return label.compareTo(other.label); // in case when it is true  

    		return Integer.compare(distance, other.distance);
    	}
    	@Override public String toString()	{		// specialized the standard-method by overriding 
    		return "(" + label + ", " + distance + ")";
    	}
    }

    public GraphTemplate(Edge[] edges) {  // create a graph with the edges from main_test with constr-param.
    	graph = new HashMap<>(edges.length);			//thats why no extra getters/ setters required
    	
    
    	for (Edge e : edges) {  //find all nodes
    		if (!graph.containsKey(e.from)) graph.put(e.from, new Node(e.from));
    		if (!graph.containsKey(e.to)) graph.put(e.to, new Node(e.to));
    	}

    	for (Edge e : edges) {	// put neighbourNodes
    		graph.get(e.from).adjacentNodes.put(graph.get(e.to), e.distance);
    	}
    }

    public void dijk(String startlabel) {  // 
    	if (!graph.containsKey(startlabel)) {  // use HashMapfunction to check graph
    		System.err.printf("Start-Node not in graph \"%s\"\n", startlabel);
    		return;
    	}
    	Node source = graph.get(startlabel);
    	TreeSet<Node> q = new TreeSet<>();  	
    	for (Node v : graph.values()) {	 // set nodes
    		v.parent = v == source ? source : null;
    		v.distance = v == source ? 0 : Integer.MAX_VALUE;
    		q.add(v);
    	} 
    	dijk(q);
    }

    private void dijk(TreeSet<Node> q) {  	// dijk's algorithm     
    	Node u, v;
    	while (!q.isEmpty()) { 
    		u = q.pollFirst(); // use StandardTreeSet Method to find nearest Node 
    		if (u.distance == Integer.MAX_VALUE) break; // because can�t reach  						
    		
    		//distances to every neighbour
    		for (HashMap.Entry<Node, Integer> a : u.adjacentNodes.entrySet()) {
    			v = a.getKey(); //actual neighbour 
    			int alternateDist = u.distance + a.getValue();
    			if (alternateDist < v.distance) { // swap when shorter distance
    				q.remove(v);
    				v.distance = alternateDist;
    				v.parent = u;
    				q.add(v);
    			} 
    		}
    	}
    }

    public void shortestWay(String endlabel) {  // from first to end output
    	if (!graph.containsKey(endlabel)) {
    		System.err.printf("No EndNode  in graph\"%s\"\n", endlabel);
    		return;
    	}

    	graph.get(endlabel).shortestWay();
    	System.out.println();
    }
}