package de.assignment3_delivery;


public class Dijkstra_Main_Test {
	 
	public static void main(String[] args) {  //main- 
		   
		System.out.println("Test 1 : ----------------------");
		GraphTemplate.Edge[] gr1 = { // Graph with an array of instances of Edges
			 new GraphTemplate.Edge("a", "b", 3),		// (startpoint,endpoint,weight)
			 new GraphTemplate.Edge("a", "c", 9),
			 new GraphTemplate.Edge("a", "f", 14),
			 new GraphTemplate.Edge("b", "c", 6),
			 new GraphTemplate.Edge("b", "d", 15),};
		GraphTemplate g1 = new GraphTemplate(gr1);
	    g1.dijk("a");   //Startpoint in algorithm
	    g1.shortestWay("d");	  //Endpoint for outstream
	      
	    System.out.println("\nTest 2: ----------------------");
	    GraphTemplate.Edge[] gr2 = { 
	    	 new GraphTemplate.Edge("aa", "bb", 200),		
	    	 new GraphTemplate.Edge("aa", "cc", 500),
	    	 new GraphTemplate.Edge("aa", "dd", 800),
	    	 new GraphTemplate.Edge("bb", "cc", 100),
	    	 new GraphTemplate.Edge("bb", "dd", 300),};
	     GraphTemplate g2 = new GraphTemplate(gr2);
	     g2.dijk("aa");   
	     g2.shortestWay("dd");	  
	 }
}
